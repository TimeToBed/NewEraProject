export interface DashboardState {
  welcomeText: string
  isSBPin: boolean
  isSBOpen: boolean
}
