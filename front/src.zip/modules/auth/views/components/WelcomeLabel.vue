<template>
  <div class="w-full">
    <h1 class="text-white font-semibold">Welcome to Argon Dashboard Pro Laravel Live Preview.</h1>
    <p class="text-light mt-4 mb-0">
      Log in and see how you can save more than 150 hours of work with CRUDs for managing: #users,
      #roles, #items, #categories, #tags and more.
    </p>
  </div>
</template>
<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'WelcomeLabel',
})
</script>
