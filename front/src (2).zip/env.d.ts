interface ImportMetaEnv {
  SERVICE_ENDPOINT: string
}
