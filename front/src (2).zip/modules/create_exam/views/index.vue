<template>
    <h3>Create Exam</h3>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'CreateExam',
  
})
</script>
  