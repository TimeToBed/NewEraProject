<template>
    <h3>Hello World</h3>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue'
  
  export default defineComponent({
    name: 'ExamList',
    
  })
  </script>
  